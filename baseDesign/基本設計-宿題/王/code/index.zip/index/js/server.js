$(document).ready(function(){
    $("#lb").click(function(){
      window.location.replace("./index.html");
    });
  });